This module extends sale_commission to introduce the use of formulas to
compute the agent commissions.
