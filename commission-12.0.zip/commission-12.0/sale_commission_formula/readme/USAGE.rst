To use this module, you need to:

* Go to Sales, Commission Types and create a commission with type formula
