This module extends the functionality of sale_commission to allow you set a
commission to pricelist item.

The commission is applied when the pricelist rule is applied, that is after changing product or quantity of sale order line.
