* `Tecnativa <https://www.tecnativa.com>`_:
  * Carlos Dauden
  * Ernesto Tejeda
* Lorenzo Battistini <lorenzo.battistini@agilebg.com>
