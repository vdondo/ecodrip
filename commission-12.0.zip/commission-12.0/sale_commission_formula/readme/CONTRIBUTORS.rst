* Davide Corio <davide.corio@abstract.it>
* Nicola Malcontenti <nicola.malcontenti@agilebg.com>
* Duc, Dao Dong <duc.dd@komit-consulting.com> (https://komit-consulting.com)
