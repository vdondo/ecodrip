To use this module, you need to:

#. Go to Sales -> Configuration -> Settings -> Pricing -> Sale Price,
   activate: "Multiple Sales Prices per Product" and select
   *Prices computed from formulas (discounts, margins, roundings)*
#. Go to Sales -> Products -> Pricelists and edit an existing one or
   create a new one
#. In the pricelist -> add a new item or open a new one
#. You will find the field commission in the pricelist item
